#ifndef _music_8bit_H_
#define _music_8bit_H_

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char m5stack_startup_music[];

#ifdef __cplusplus
}
#endif

#endif
