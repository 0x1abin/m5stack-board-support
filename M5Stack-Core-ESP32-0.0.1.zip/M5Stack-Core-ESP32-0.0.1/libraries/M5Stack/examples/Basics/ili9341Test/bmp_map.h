#ifndef _BMP_MAP_H_
#define _BMP_MAP_H_

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char gImage_logo[];
extern const unsigned char gImage_select_backguand[];

extern const unsigned char gImage_clock[];
extern const unsigned char gImage_guide[];
extern const unsigned char gImage_wifi_scaner[];
extern const unsigned char gImage_home_station[];
extern const unsigned char gImage_guitar[];
extern const unsigned char gImage_piano[];
extern const unsigned char gImage_remote[];
extern const unsigned char gImage_tracker[];
extern const unsigned char gImage_voice[];
extern const unsigned char gImage_weather[];
extern const unsigned char gImage_watch[];
extern const unsigned char gImage_robot[];
extern const unsigned char gImage_Massage[];
extern const unsigned char gImage_laser[];
extern const unsigned char gImage_detect[];
extern const unsigned char gImage_crack[];
extern const unsigned char gImage_drone[];
extern const unsigned char gImage_socket[];
extern const unsigned char gImage_controller[];
extern const unsigned char gImage_temperature[];

#ifdef __cplusplus
}
#endif

#endif
