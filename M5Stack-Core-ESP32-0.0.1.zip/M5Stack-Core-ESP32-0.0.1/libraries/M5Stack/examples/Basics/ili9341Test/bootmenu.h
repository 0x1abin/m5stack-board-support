//tmp

#ifndef BOOTMENU_H_
#define	BOOTMENU_H_

#include "M5Stack.h"

extern void drawTitle(char *str, int color);
extern int selectMenu();

#endif
