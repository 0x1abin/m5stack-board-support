#ifndef _BMP_H_
#define _BMP_H_

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char gImage_snake[];

#ifdef __cplusplus
}
#endif

#endif
