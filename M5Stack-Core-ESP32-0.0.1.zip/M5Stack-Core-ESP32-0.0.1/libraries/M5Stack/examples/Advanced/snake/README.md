# esp32-snake
Snake game for ESP32 and ILI9341 screen
