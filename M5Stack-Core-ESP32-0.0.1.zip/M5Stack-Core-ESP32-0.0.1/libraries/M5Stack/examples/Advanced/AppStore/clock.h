#ifndef _CLOCK_H_
#define _CLOCK_H_

#include "M5Stack.h"
#include "NTPClient.h"
#include "TimerObject.h"

void clock_setup();
void clock_loop();

#endif
