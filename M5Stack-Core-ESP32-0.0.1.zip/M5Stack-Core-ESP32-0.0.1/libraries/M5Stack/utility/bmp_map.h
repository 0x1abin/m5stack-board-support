#ifndef _BMP_MAP_H_
#define _BMP_MAP_H_

#ifdef __cplusplus
extern "C" {
#endif

extern const unsigned char gImage_logoM5[];

#ifdef __cplusplus
}
#endif

#endif
