#include "Speaker.h"

void SPEAKER::begin() {
    ledcSetup(TONE_PIN_CHANNEL, 0, 13);
    ledcAttachPin(SPEAKER_PIN, TONE_PIN_CHANNEL);
    //   ledcWrite(TONE_PIN_CHANNEL, 128);
    //   ledcWriteTone(TONE_PIN_CHANNEL, double freq);
}

void SPEAKER::beep() {
    tone(1000, 200);
}

void SPEAKER::tone(uint16_t frequency) {
    ledcWriteTone(TONE_PIN_CHANNEL, frequency);
}

void SPEAKER::tone(uint16_t frequency, uint32_t duration) {
    tone(frequency);
    _count = millis() + duration;
    speaker_on = 1;
}

void SPEAKER::setVolume(uint32_t volume) {
    // ledcWrite(TONE_PIN_CHANNEL, (uint32_t)volume);
    // ledcAnalogWrite(TONE_PIN_CHANNEL, brightness);
    // ledcAnalogWrite(TONE_PIN_CHANNEL, volume)
    uint32_t valueMax = 255;
    // calculate duty, 8191 from 2 ^ 13 - 1
    uint32_t duty = (8191 / valueMax) * min(volume, valueMax);

    // write duty to LEDC
    ledcWrite(TONE_PIN_CHANNEL, duty);
}

void SPEAKER::mute() {
    ledcWriteTone(TONE_PIN_CHANNEL, 0);
    digitalWrite(SPEAKER_PIN, 0);
}

void SPEAKER::update() {
    if(speaker_on) {
        if(millis() > _count) {
            speaker_on = 0;
            mute();
        }
    }
}
