#ifndef BATTERY_H
#define	BATTERY_H

#include <Arduino.h>

#endif

