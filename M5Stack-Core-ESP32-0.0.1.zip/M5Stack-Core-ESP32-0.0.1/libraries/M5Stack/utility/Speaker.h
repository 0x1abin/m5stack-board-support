#include "Arduino.h"
#include "config.h"
#include "esp32-hal-dac.h"

class SPEAKER {
public:
    void begin();
    void beep();
    void mute();
    void tone(uint16_t frequency);
    void tone(uint16_t frequency, uint32_t duration);
    void setVolume(uint32_t volume);
    void update();
    
private:
    uint32_t _count;
    bool speaker_on;
};
